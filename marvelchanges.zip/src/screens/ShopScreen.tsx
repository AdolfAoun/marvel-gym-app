import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useFocusEffect } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import { GlowingChips } from '@/components/GlowingChips';
import { PremiumScreenBackground } from '@/components/PremiumScreenBackground';
import { MarvelMarks } from '@/components/PremiumUI';
import {
  premiumColors,
  premiumGradients,
  premiumShadow,
  premiumGlow,
} from '@/constants/premiumTheme';
import { productService, voucherService } from '@/services';
import type { Product, ProductCategory, Voucher, VoucherStatus } from '@/types';

const accentColor = premiumColors.red;
const wineColor = premiumColors.redBright;
const surfaceColor = premiumColors.surface;
const textColor = premiumColors.text;
const mutedColor = premiumColors.textMuted;

type SortMode = 'price-asc' | 'price-desc';
type OrderTab = 'Confirmed' | 'Canceled';

function formatPrice(price: number, currency: string) {
  return `${currency} ${price.toFixed(2)}`;
}

function getProductImageLabel(product: Product) {
  return product.name
    .split(' ')
    .map((part) => part.slice(0, 1))
    .join('')
    .slice(0, 2)
    .toUpperCase();
}

function getDisplayProductImageUri(product: Product) {
  if (!product.imageUrl || product.imageUrl.includes('example.com')) {
    return undefined;
  }
  return product.imageUrl;
}

function formatVoucherDate(value: string) {
  return new Intl.DateTimeFormat('en', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date(value));
}

function getVoucherStatusColor(status: VoucherStatus) {
  if (status === 'Confirmed') return premiumColors.success;
  if (status === 'Canceled') return premiumColors.textMuted;
  return premiumColors.warning;
}

export default function ShopScreen() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('Gym Equipment');
  const [sortMode, setSortMode] = useState<SortMode>('price-asc');
  const [isLoading, setIsLoading] = useState(true);
  const [shopVouchers, setShopVouchers] = useState<Voucher[]>([]);
  const [orderTab, setOrderTab] = useState<OrderTab>('Confirmed');
  const [pendingVoucherProduct, setPendingVoucherProduct] = useState<Product>();
  const [voucherQuantity, setVoucherQuantity] = useState(1);
  const [isCreatingVoucher, setIsCreatingVoucher] = useState(false);
  const [toastText, setToastText] = useState('');

  const loadData = useCallback(async () => {
    const [nextProducts, nextCategories, nextVouchers] = await Promise.all([
      productService.getProducts(),
      productService.getProductCategories(),
      voucherService.getVouchers(),
    ]);
    setProducts(nextProducts.filter((item) => item.isActive));
    setCategories(nextCategories);
    setSelectedCategory(nextCategories[0] ?? 'Gym Equipment');
    setShopVouchers(nextVouchers.filter((v) => v.type === 'Shop Reservation'));
    setIsLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData]),
  );

  const visibleProducts = useMemo(() => {
    return products
      .filter((product) => product.category === selectedCategory)
      .sort((a, b) =>
        sortMode === 'price-asc' ? a.price - b.price : b.price - a.price,
      );
  }, [products, selectedCategory, sortMode]);

  const pendingVouchers = shopVouchers.filter((v) => v.status === 'Pending');
  const orderedVouchers = shopVouchers.filter((v) => v.status === orderTab);

  const handleCreateVoucher = async () => {
    if (!pendingVoucherProduct) return;
    setIsCreatingVoucher(true);
    try {
      const totalAmount = pendingVoucherProduct.price * voucherQuantity;
      const label = voucherQuantity > 1
        ? `${voucherQuantity}x ${pendingVoucherProduct.name}`
        : pendingVoucherProduct.name;
      await voucherService.createShopVoucher(label, totalAmount);
      await loadData();
      setPendingVoucherProduct(undefined);
      setVoucherQuantity(1);
      setToastText('Voucher created successfully');
      setTimeout(() => setToastText(''), 2500);
    } finally {
      setIsCreatingVoucher(false);
    }
  };

  const handleCancelPendingVoucher = async (voucherId: string) => {
    await voucherService.cancelVoucher(voucherId);
    await loadData();
  };

  if (isLoading) {
    return (
      <PremiumScreenBackground>
        <StatusBar style="light" />
        <View style={styles.loadingState}>
          <ActivityIndicator color={accentColor} />
          <Text style={styles.loadingText}>Loading marketplace...</Text>
        </View>
      </PremiumScreenBackground>
    );
  }

  return (
    <PremiumScreenBackground>
      <StatusBar style="light" />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>

        {/* Hero Banner */}
        <LinearGradient
          colors={premiumGradients.redPanel}
          start={{ x: 0.1, y: 0 }}
          end={{ x: 0.9, y: 1 }}
          style={styles.heroCard}>
          <View pointerEvents="none" style={styles.heroGloss} />
          <MarvelMarks variant="corner" color="#FFFFFF" />
          <Text style={styles.kicker}>Gym Shop</Text>
          <Text style={styles.heroTitle}>Premium gym essentials.</Text>
          <Text style={styles.heroBody}>
            Browse products, create reservations, and track your orders — all in one place.
          </Text>
          <View style={styles.heroStatsRow}>
            <View style={styles.heroStatPill}>
              <Text style={styles.heroStatValue}>{products.length}</Text>
              <Text style={styles.heroStatLabel}>products</Text>
            </View>
            <View style={styles.heroStatPill}>
              <Text style={styles.heroStatValue}>{pendingVouchers.length}</Text>
              <Text style={styles.heroStatLabel}>pending</Text>
            </View>
            <View style={styles.heroStatPill}>
              <Text style={styles.heroStatValue}>{orderedVouchers.length}</Text>
              <Text style={styles.heroStatLabel}>orders</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Category Filter */}
        <View style={styles.sectionHeading}>
          <View style={styles.accentBar} />
          <View style={styles.sectionHeadingText}>
            <Text style={styles.sectionEyebrow}>Categories</Text>
            <Text style={styles.sectionHeadingTitle}>Browse by category</Text>
          </View>
        </View>

        <View style={styles.categoryList}>
          <GlowingChips
            items={categories.map((c) => ({ key: c, label: c }))}
            selectedKey={selectedCategory}
            onSelect={(key) => setSelectedCategory(key as ProductCategory)}
          />
        </View>

        {/* Sort + Products Header */}
        <View style={styles.sectionHeading}>
          <View style={styles.accentBar} />
          <View style={styles.sectionHeadingText}>
            <Text style={styles.sectionEyebrow}>Products</Text>
            <Text style={styles.productCategoryHeading}>{selectedCategory}</Text>
          </View>
          <View style={styles.sortGroup}>
            <GlowingChips
              variant="segment"
              items={[
                { key: 'price-asc', label: 'Low' },
                { key: 'price-desc', label: 'High' },
              ]}
              selectedKey={sortMode}
              onSelect={(key) => setSortMode(key as SortMode)}
            />
          </View>
        </View>

        {/* Product Grid */}
        <View style={styles.productGrid}>
          {visibleProducts.map((product) => {
            const displayImageUri = getDisplayProductImageUri(product);
            return (
              <View
                key={product.id}
                style={[
                  styles.productCard,
                  !product.isAvailable && styles.productCardUnavailable,
                ]}>
                <View style={styles.productImage}>
                  {displayImageUri ? (
                    <Image
                      source={{ uri: displayImageUri }}
                      style={styles.productPhoto}
                      resizeMode="cover"
                    />
                  ) : (
                    <>
                      <View style={styles.productImageGlow} />
                      <View style={styles.productImageFrame}>
                        <Text style={styles.productImageInitialText}>
                          {getProductImageLabel(product)}
                        </Text>
                      </View>
                      <Text style={styles.productImageText}>Photo soon</Text>
                    </>
                  )}
                  {!product.isAvailable && (
                    <View style={styles.unavailableOverlay}>
                      <Text style={styles.unavailableText}>Out of Stock</Text>
                    </View>
                  )}
                </View>

                <View style={styles.productCopy}>
                  <Text style={styles.productName}>{product.name}</Text>
                  {product.description ? (
                    <Text style={styles.productDescription}>{product.description}</Text>
                  ) : null}
                </View>

                <View style={styles.productFooter}>
                  <View style={styles.priceStatusRow}>
                    <Text style={styles.productPrice}>
                      {formatPrice(product.price, product.currency)}
                    </Text>
                    <View
                      style={[
                        styles.availabilityPill,
                        !product.isAvailable && styles.availabilityPillUnavailable,
                      ]}>
                      <Text
                        style={[
                          styles.availabilityPillText,
                          !product.isAvailable && styles.availabilityPillTextUnavailable,
                        ]}>
                        {product.isAvailable ? 'Available' : 'Out of stock'}
                      </Text>
                    </View>
                  </View>

                  <Pressable
                    disabled={!product.isAvailable}
                    onPress={() => {
                      setVoucherQuantity(1);
                      setPendingVoucherProduct(product);
                    }}
                    style={({ pressed }) => [
                      styles.voucherButton,
                      !product.isAvailable && styles.voucherButtonDisabled,
                      pressed && product.isAvailable && styles.buttonPressed,
                    ]}>
                    <Text style={styles.voucherButtonText}>Create Voucher</Text>
                  </Pressable>
                </View>
              </View>
            );
          })}
        </View>

        {/* My Vouchers (Pending) */}
        <View style={styles.sectionHeading}>
          <View style={styles.accentBar} />
          <View style={styles.sectionHeadingText}>
            <Text style={styles.sectionEyebrow}>Pending</Text>
            <Text style={styles.sectionHeadingTitle}>My Vouchers</Text>
          </View>
          <Text style={styles.sectionHint}>{pendingVouchers.length} active</Text>
        </View>

        {pendingVouchers.length === 0 ? (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyTitle}>No pending vouchers</Text>
            <Text style={styles.emptyBody}>
              Create a voucher from any available product above and bring it to the counter.
            </Text>
          </View>
        ) : (
          <View style={styles.voucherList}>
            {pendingVouchers.map((voucher) => (
              <View key={voucher.id} style={styles.voucherCard}>
                <View style={styles.voucherRail} />
                <View style={styles.voucherContent}>
                  <View style={styles.voucherTopRow}>
                    <View style={styles.voucherStatusPill}>
                      <View style={[styles.voucherStatusDot, { backgroundColor: premiumColors.warning }]} />
                      <Text style={[styles.voucherStatusText, { color: premiumColors.warning }]}>Pending</Text>
                    </View>
                    <Text style={styles.voucherDate}>{formatVoucherDate(voucher.date)}</Text>
                  </View>
                  <Text style={styles.voucherDescription}>{voucher.description}</Text>
                  <View style={styles.voucherFooter}>
                    <Text style={styles.voucherAmount}>
                      {voucher.currency} {voucher.amount.toFixed(2)}
                    </Text>
                    <Pressable
                      onPress={() => handleCancelPendingVoucher(voucher.id)}
                      style={({ pressed }) => [
                        styles.cancelVoucherButton,
                        pressed && styles.buttonPressed,
                      ]}>
                      <Text style={styles.cancelVoucherText}>Cancel</Text>
                    </Pressable>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* My Orders */}
        <View style={styles.sectionHeading}>
          <View style={styles.accentBar} />
          <View style={styles.sectionHeadingText}>
            <Text style={styles.sectionEyebrow}>History</Text>
            <Text style={styles.sectionHeadingTitle}>My Orders</Text>
          </View>
        </View>

        <View style={styles.orderTabsRow}>
          {(['Confirmed', 'Canceled'] as OrderTab[]).map((tab) => (
            <Pressable
              key={tab}
              onPress={() => setOrderTab(tab)}
              style={[
                styles.orderTab,
                orderTab === tab && styles.orderTabActive,
              ]}>
              <Text style={[
                styles.orderTabText,
                orderTab === tab && styles.orderTabTextActive,
              ]}>
                {tab}
              </Text>
            </Pressable>
          ))}
        </View>

        {orderedVouchers.length === 0 ? (
          <View style={[styles.emptyCard, { marginBottom: 0 }]}>
            <Text style={styles.emptyTitle}>No {orderTab.toLowerCase()} orders</Text>
            <Text style={styles.emptyBody}>
              {orderTab === 'Confirmed'
                ? 'Orders confirmed by staff will appear here.'
                : 'Cancelled orders will appear here.'}
            </Text>
          </View>
        ) : (
          <View style={styles.voucherList}>
            {orderedVouchers.map((voucher) => (
              <View key={voucher.id} style={styles.voucherCard}>
                <View style={[styles.voucherRail, { backgroundColor: getVoucherStatusColor(voucher.status) }]} />
                <View style={styles.voucherContent}>
                  <View style={styles.voucherTopRow}>
                    <View style={styles.voucherStatusPill}>
                      <View style={[styles.voucherStatusDot, { backgroundColor: getVoucherStatusColor(voucher.status) }]} />
                      <Text style={[styles.voucherStatusText, { color: getVoucherStatusColor(voucher.status) }]}>
                        {voucher.status}
                      </Text>
                    </View>
                    <Text style={styles.voucherDate}>{formatVoucherDate(voucher.date)}</Text>
                  </View>
                  <Text style={styles.voucherDescription}>{voucher.description}</Text>
                  <Text style={styles.voucherAmount}>
                    {voucher.currency} {voucher.amount.toFixed(2)}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Create Voucher Modal */}
      <Modal
        transparent
        visible={Boolean(pendingVoucherProduct)}
        animationType="fade">
        <View style={styles.modalOverlay}>
          <Pressable
            style={styles.modalBackdrop}
            onPress={() => setPendingVoucherProduct(undefined)}
          />
          <View style={styles.modalCard}>
            <Text style={styles.modalKicker}>Shop Reservation</Text>
            <Text style={styles.modalTitle}>Create Voucher</Text>
            {pendingVoucherProduct ? (
              <>
                <Text style={styles.modalProductName}>{pendingVoucherProduct.name}</Text>
                <Text style={styles.modalProductPrice}>
                  {formatPrice(pendingVoucherProduct.price, pendingVoucherProduct.currency)} per unit
                </Text>
                <View style={styles.quantityRow}>
                  <Text style={styles.quantityLabel}>Quantity</Text>
                  <View style={styles.quantityControl}>
                    <Pressable
                      onPress={() => setVoucherQuantity((q) => Math.max(1, q - 1))}
                      style={({ pressed }) => [styles.quantityButton, pressed && styles.buttonPressed]}>
                      <Text style={styles.quantityButtonText}>−</Text>
                    </Pressable>
                    <Text style={styles.quantityValue}>{voucherQuantity}</Text>
                    <Pressable
                      onPress={() => setVoucherQuantity((q) => Math.min(10, q + 1))}
                      style={({ pressed }) => [styles.quantityButton, pressed && styles.buttonPressed]}>
                      <Text style={styles.quantityButtonText}>+</Text>
                    </Pressable>
                  </View>
                </View>
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total</Text>
                  <Text style={styles.totalValue}>
                    {formatPrice(pendingVoucherProduct.price * voucherQuantity, pendingVoucherProduct.currency)}
                  </Text>
                </View>
                <Text style={styles.modalNote}>
                  Bring this voucher to the counter and pay in cash to complete your reservation.
                </Text>
              </>
            ) : null}
            <View style={styles.modalActions}>
              <Pressable
                onPress={() => setPendingVoucherProduct(undefined)}
                style={({ pressed }) => [styles.modalSecondary, pressed && styles.buttonPressed]}>
                <Text style={styles.modalSecondaryText}>Cancel</Text>
              </Pressable>
              <Pressable
                onPress={handleCreateVoucher}
                disabled={isCreatingVoucher}
                style={({ pressed }) => [
                  styles.modalPrimary,
                  isCreatingVoucher && styles.buttonDisabled,
                  pressed && !isCreatingVoucher && styles.buttonPressed,
                ]}>
                {isCreatingVoucher ? (
                  <ActivityIndicator color="#FFFFFF" size="small" />
                ) : (
                  <Text style={styles.modalPrimaryText}>Create Voucher</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* Toast */}
      {toastText ? (
        <View style={styles.toast} pointerEvents="none">
          <Text style={styles.toastText}>{toastText}</Text>
        </View>
      ) : null}
    </PremiumScreenBackground>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 20,
    paddingTop: 72,
    paddingBottom: 132,
  },
  loadingState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  loadingText: {
    color: mutedColor,
    fontSize: 14,
    fontWeight: '700',
  },
  heroCard: {
    position: 'relative',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.16)',
    borderRadius: 26,
    padding: 22,
    marginBottom: 20,
    shadowColor: premiumColors.red,
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.4,
    shadowRadius: 26,
    elevation: 10,
  },
  heroGloss: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '50%',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
  },
  kicker: {
    color: 'rgba(255, 255, 255, 0.78)',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  heroTitle: {
    color: '#FFFFFF',
    fontSize: 30,
    fontWeight: '900',
    lineHeight: 35,
    marginTop: 6,
  },
  heroBody: {
    color: 'rgba(255, 255, 255, 0.86)',
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 20,
    marginTop: 10,
  },
  heroStatsRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 20,
  },
  heroStatPill: {
    flex: 1,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    padding: 12,
  },
  heroStatValue: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: '900',
  },
  heroStatLabel: {
    color: 'rgba(255, 255, 255, 0.82)',
    fontSize: 10,
    fontWeight: '900',
    marginTop: 2,
    textTransform: 'uppercase',
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
    marginTop: 4,
  },
  accentBar: {
    width: 4,
    height: 36,
    borderRadius: 3,
    backgroundColor: premiumColors.redBright,
  },
  sectionHeadingText: {
    flex: 1,
  },
  sectionEyebrow: {
    color: premiumColors.redBright,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginBottom: 2,
    textTransform: 'uppercase',
  },
  sectionHeadingTitle: {
    color: textColor,
    fontSize: 21,
    fontWeight: '900',
  },
  sectionHint: {
    color: mutedColor,
    fontSize: 12,
    fontWeight: '900',
  },
  categoryList: {
    paddingBottom: 14,
  },
  productCategoryHeading: {
    color: textColor,
    fontSize: 21,
    fontWeight: '900',
  },
  sortGroup: {
    width: 132,
  },
  productGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  productCard: {
    minHeight: 280,
    flexBasis: '47%',
    flexGrow: 1,
    justifyContent: 'space-between',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: premiumColors.glassBorder,
    borderRadius: 24,
    backgroundColor: surfaceColor,
    padding: 12,
    ...premiumShadow,
  },
  productCardUnavailable: {
    opacity: 0.62,
  },
  productImage: {
    height: 120,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    overflow: 'hidden',
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.04)',
    marginBottom: 12,
  },
  productImageGlow: {
    position: 'absolute',
    left: -26,
    bottom: -28,
    width: 84,
    height: 84,
    borderRadius: 42,
    backgroundColor: 'rgba(225, 29, 46, 0.14)',
  },
  productImageFrame: {
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.14)',
    borderRadius: 16,
    backgroundColor: 'rgba(7, 8, 12, 0.78)',
  },
  productPhoto: {
    width: '100%',
    height: '100%',
  },
  productImageText: {
    color: accentColor,
    fontSize: 10,
    fontWeight: '900',
    marginTop: 6,
    textTransform: 'uppercase',
  },
  productImageInitialText: {
    color: accentColor,
    fontSize: 20,
    fontWeight: '900',
  },
  unavailableOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.52)',
    borderRadius: 18,
  },
  unavailableText: {
    color: premiumColors.warning,
    fontSize: 11,
    fontWeight: '900',
    textTransform: 'uppercase',
  },
  productCopy: {
    flex: 1,
  },
  productName: {
    color: textColor,
    fontSize: 14,
    fontWeight: '900',
    lineHeight: 19,
  },
  productDescription: {
    color: mutedColor,
    fontSize: 11,
    fontWeight: '700',
    lineHeight: 16,
    marginTop: 4,
  },
  productFooter: {
    borderTopWidth: 1,
    borderTopColor: premiumColors.border,
    marginTop: 10,
    paddingTop: 10,
    gap: 8,
  },
  priceStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 6,
  },
  productPrice: {
    color: wineColor,
    fontSize: 14,
    fontWeight: '900',
  },
  availabilityPill: {
    borderWidth: 1,
    borderColor: 'rgba(34, 197, 94, 0.16)',
    borderRadius: 999,
    backgroundColor: 'rgba(34, 197, 94, 0.07)',
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  availabilityPillUnavailable: {
    borderColor: 'rgba(245, 158, 11, 0.18)',
    backgroundColor: 'rgba(245, 158, 11, 0.07)',
  },
  availabilityPillText: {
    color: '#74DFA0',
    fontSize: 7,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  availabilityPillTextUnavailable: {
    color: '#EAB308',
  },
  voucherButton: {
    minHeight: 38,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    backgroundColor: accentColor,
    shadowColor: wineColor,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 4,
  },
  voucherButtonDisabled: {
    opacity: 0.4,
  },
  voucherButtonText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '900',
  },
  emptyCard: {
    borderWidth: 1,
    borderColor: premiumColors.border,
    borderRadius: 22,
    backgroundColor: premiumColors.surfaceSoft,
    padding: 18,
    marginBottom: 16,
  },
  emptyTitle: {
    color: textColor,
    fontSize: 15,
    fontWeight: '900',
  },
  emptyBody: {
    color: mutedColor,
    fontSize: 13,
    fontWeight: '700',
    lineHeight: 19,
    marginTop: 5,
  },
  voucherList: {
    gap: 10,
    marginBottom: 20,
  },
  voucherCard: {
    flexDirection: 'row',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: premiumColors.glassBorder,
    borderRadius: 20,
    backgroundColor: surfaceColor,
    ...premiumShadow,
  },
  voucherRail: {
    width: 4,
    backgroundColor: premiumColors.warning,
  },
  voucherContent: {
    flex: 1,
    padding: 14,
    gap: 6,
  },
  voucherTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  voucherStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  voucherStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  voucherStatusText: {
    fontSize: 11,
    fontWeight: '900',
    textTransform: 'uppercase',
  },
  voucherDate: {
    color: mutedColor,
    fontSize: 11,
    fontWeight: '800',
  },
  voucherDescription: {
    color: textColor,
    fontSize: 14,
    fontWeight: '900',
    lineHeight: 19,
  },
  voucherFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 2,
  },
  voucherAmount: {
    color: wineColor,
    fontSize: 14,
    fontWeight: '900',
  },
  cancelVoucherButton: {
    minHeight: 30,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(177, 18, 38, 0.26)',
    borderRadius: 999,
    backgroundColor: 'rgba(177, 18, 38, 0.08)',
    paddingHorizontal: 14,
  },
  cancelVoucherText: {
    color: wineColor,
    fontSize: 11,
    fontWeight: '900',
  },
  orderTabsRow: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: premiumColors.border,
    borderRadius: 16,
    backgroundColor: premiumColors.surfaceSoft,
    marginBottom: 14,
    padding: 4,
    gap: 4,
  },
  orderTab: {
    flex: 1,
    minHeight: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
  },
  orderTabActive: {
    backgroundColor: accentColor,
    shadowColor: wineColor,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 4,
  },
  orderTabText: {
    color: mutedColor,
    fontSize: 13,
    fontWeight: '900',
  },
  orderTabTextActive: {
    color: '#FFFFFF',
  },
  modalOverlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.62)',
    padding: 20,
  },
  modalBackdrop: {
    ...StyleSheet.absoluteFillObject,
  },
  modalCard: {
    width: '100%',
    maxWidth: 420,
    borderWidth: 1,
    borderColor: premiumColors.glassBorder,
    borderRadius: 28,
    backgroundColor: premiumColors.surface,
    padding: 22,
    ...premiumShadow,
  },
  modalKicker: {
    color: wineColor,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1.2,
    marginBottom: 5,
    textTransform: 'uppercase',
  },
  modalTitle: {
    color: textColor,
    fontSize: 24,
    fontWeight: '900',
    marginBottom: 14,
  },
  modalProductName: {
    color: textColor,
    fontSize: 17,
    fontWeight: '900',
  },
  modalProductPrice: {
    color: mutedColor,
    fontSize: 13,
    fontWeight: '700',
    marginTop: 3,
    marginBottom: 18,
  },
  quantityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  quantityLabel: {
    color: textColor,
    fontSize: 15,
    fontWeight: '900',
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderWidth: 1,
    borderColor: premiumColors.border,
    borderRadius: 14,
    backgroundColor: premiumColors.surfaceSoft,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  quantityButton: {
    width: 28,
    height: 28,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    backgroundColor: accentColor,
  },
  quantityButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
  },
  quantityValue: {
    color: textColor,
    fontSize: 18,
    fontWeight: '900',
    minWidth: 24,
    textAlign: 'center',
  },
  totalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: premiumColors.border,
    paddingTop: 14,
    marginBottom: 12,
  },
  totalLabel: {
    color: mutedColor,
    fontSize: 13,
    fontWeight: '900',
    textTransform: 'uppercase',
  },
  totalValue: {
    color: wineColor,
    fontSize: 20,
    fontWeight: '900',
  },
  modalNote: {
    color: mutedColor,
    fontSize: 12,
    fontWeight: '700',
    lineHeight: 18,
    marginBottom: 18,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 10,
  },
  modalSecondary: {
    flex: 1,
    minHeight: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: premiumColors.borderStrong,
    borderRadius: 18,
    backgroundColor: premiumColors.surfaceSoft,
  },
  modalSecondaryText: {
    color: wineColor,
    fontSize: 13,
    fontWeight: '900',
  },
  modalPrimary: {
    flex: 1,
    minHeight: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 18,
    backgroundColor: accentColor,
    ...premiumGlow,
  },
  modalPrimaryText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '900',
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonPressed: {
    opacity: 0.76,
  },
  toast: {
    position: 'absolute',
    bottom: 120,
    left: 24,
    right: 24,
    borderRadius: 18,
    backgroundColor: 'rgba(34, 197, 94, 0.15)',
    borderWidth: 1,
    borderColor: 'rgba(34, 197, 94, 0.3)',
    padding: 14,
    alignItems: 'center',
  },
  toastText: {
    color: '#74DFA0',
    fontSize: 13,
    fontWeight: '900',
  },
});
